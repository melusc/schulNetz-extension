module.exports = {
  plugins: [
    '@babel/plugin-syntax-class-properties',
    '@babel/plugin-transform-react-jsx',
  ],
};
